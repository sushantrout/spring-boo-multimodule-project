package com.tech.servicelayer.service;

import org.springframework.stereotype.Service;

import com.tech.datalayer.entity.Employee;
import com.tech.datalayer.repository.EmployeeRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class EmployeeService {
	private final EmployeeRepository employeeRepository;

	public Employee save(Employee employee) {
		return employeeRepository.save(employee);
	}
}
