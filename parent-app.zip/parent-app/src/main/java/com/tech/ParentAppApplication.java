package com.tech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParentAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParentAppApplication.class, args);
	}

}
